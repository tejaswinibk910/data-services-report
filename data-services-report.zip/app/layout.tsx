import type { Metadata } from 'next'
import './globals.css'
import DotGrid from './components/DotGrid'
import DarkModeToggle from './components/DarkModeToggle'

export const metadata: Metadata = {
  title: 'Data Services Annual Report 2024-2025',
  description: 'University of Rochester Libraries - Data Services Team Annual Report',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>
        <DotGrid />
        <DarkModeToggle />
        {children}
      </body>
    </html>
  )
}