'use client'

import { useEffect, useRef } from 'react'
import { gsap } from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import data from '../utils/data.json'

gsap.registerPlugin(ScrollTrigger)

export default function Team() {
  const sectionRef = useRef<HTMLElement>(null)
  const cardsRef = useRef<HTMLDivElement[]>([])

  useEffect(() => {
    const ctx = gsap.context(() => {
      cardsRef.current.forEach((card) => {
        gsap.from(card, {
          scrollTrigger: {
            trigger: card,
            start: 'top bottom-=100',
            end: 'top center+=100',
            scrub: 0.5,
          },
          y: 40,
          opacity: 0,
        })
      })
    }, sectionRef)

    return () => ctx.revert()
  }, [])

  return (
    <section 
      ref={sectionRef} 
      className="min-h-screen flex items-center py-20 px-6 relative"
      style={{ backgroundColor: 'rgba(0, 30, 95, 0.2)', position: 'relative', zIndex: 10 }}
    >
      <div className="max-w-6xl mx-auto w-full" style={{ position: 'relative', zIndex: 60 }}>
        <div style={{ color: '#FFC200', fontSize: '0.875rem', fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: '1rem' }}>
          Part [03]
        </div>
        <h2 className="font-serif font-bold mb-4" style={{ color: '#FFD82B' }}>The Team</h2>
        <div style={{ width: '80px', height: '4px', background: 'linear-gradient(90deg, #FFD82B, #FFC200)', marginBottom: '3rem' }} />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-16">
          {data.team_members.map((member, index) => (
            <div
              key={member.name}
              ref={(el) => {
                if (el) cardsRef.current[index] = el
              }}
              className="rounded-2xl p-8 transition-all duration-300 hover:-translate-y-1"
              style={{
                backgroundColor: '#001E5F',
                border: '2px solid rgba(255, 216, 43, 0.3)'
              }}
            >
              <div className="flex items-start gap-6">
                <div 
                  className="w-24 h-24 rounded-full flex items-center justify-center text-3xl font-bold flex-shrink-0"
                  style={{
                    background: 'linear-gradient(135deg, #FFD82B, #FFC200)',
                    color: '#001E5F'
                  }}
                >
                  {member.name.split(' ').map(n => n[0]).join('')}
                </div>
                
                <div className="flex-1">
                  <h3 className="text-2xl font-bold mb-1" style={{ color: '#FFD82B' }}>
                    {member.name}
                  </h3>
                  <p className="font-semibold mb-2" style={{ color: '#FFC200' }}>
                    {member.title}
                  </p>
                  <p className="text-sm mb-3" style={{ color: '#B7D3FF' }}>
                    Spirit Animal: <span className="font-medium">{member.bird}</span>
                  </p>
                  <p className="leading-relaxed text-sm mb-3" style={{ color: '#E8E8E8' }}>
                    {member.description}
                  </p>
                  <p 
                    className="text-xs italic pl-3"
                    style={{ 
                      color: '#66A2FF',
                      borderLeft: '2px solid #FFD82B'
                    }}
                  >
                    {member.traits}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}